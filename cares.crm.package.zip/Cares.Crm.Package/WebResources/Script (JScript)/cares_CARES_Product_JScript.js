/*
	Dependencies: 'cares_jqueryrestdataoperationfunctions' webresource
*/

if (typeof (Cares_CaresProduct) == "undefined") { Cares_CaresProduct = { __namespace: true }; }

Cares_CaresProduct =
    {
        EnableRuleForProductManualRefresh: function () {
            //Get Login user Roles
        var userRoles = Xrm.Page.context.getUserRoles();
        debugger;
            if (userRoles != null && userRoles != undefined) {
                for (var i = 0; i < userRoles.length; i++) {
                    var role = retrieveRecordCustom(userRoles[i], "RoleSet");
                    if (role != null) {
                        if (role.Name.indexOf("PDC Admin") > -1)
                            return true;
                    }
                }
            }
            return false;
        },

        RefreshCatalog: function () {
            debugger;
            var productManualRefreshStatusEntRecord = GetCARESConfigurationRecord("ProductManualRefreshStatus");
            var productManualRefreshStatus = productManualRefreshStatusEntRecord[0].cares_Value;
            var productManualRefreshStatusGuid = productManualRefreshStatusEntRecord[0].cares_caresconfigurationId;
			if(productManualRefreshStatus == 'InProgress')
			{
				alert("'Refresh Catalog' process is in progress.");
				
			}
			else if(productManualRefreshStatus != 'Requested')
            {
                Cares_CaresProduct.UpdateProductManualRefreshStatusToRequested(productManualRefreshStatusGuid);
			}
            else{
				alert("'Refresh Catalog' request has already been submitted.");
			}
        },

        UpdateProductManualRefreshStatusToRequested: function (id) {
            //Update Expiry and Call Allotment
            var item = new Object();
            item.cares_Value = 'Requested';
            SDK.REST.updateRecord(id, item, 'cares_caresconfiguration',
                function () {
                    alert("'Refresh Catalog' request has been submitted successfully. You will receive a notitication email when the process is completed.");
                },
                Cares_CaresProduct.errorHandler
            );
        },

        errorHandler: function (error) {
            alert(error.message);
        },

    };
